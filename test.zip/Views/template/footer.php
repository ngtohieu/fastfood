<footer class="footer spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="footer__about">
                        <div class="footer__about__logo">
                            <a href="./index.html"><img src="resource/img/logo.png" alt=""></a>
                        </div>
                        <ul>
                            <li>Địa chỉ: Hồ chí minh</li>
                            <li>Phone: +8499999999999</li>
                            <li>Email: huanrose@colamcoan@gmail.com</li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 offset-lg-1">
                    <div class="footer__widget">
                        <h6>Liên kết hữu ích</h6>
                        <ul>
                            <li><a href="#">Về chúng tôi</a></li>
                        </ul>
                        <ul>
                            <li><a href="#">Liên Hệ</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4 col-md-12">
                    <div class="footer__widget">
                        <h6>Nhận thông báo mới nhất</h6>
                        <p>Nhận Email khi có khuyến mãi</p>
                        <form action="#">
                            <input type="text" placeholder="Nhập Email của bạn">
                            <button type="submit" class="site-btn">Đăng kí</button>
                        </form>
                        <div class="footer__widget__social">
                            <a href="#"><i class="fa fa-facebook"></i></a>
                            <a href="#"><i class="fa fa-instagram"></i></a>
                            <a href="#"><i class="fa fa-twitter"></i></a>
                            <a href="#"><i class="fa fa-pinterest"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="footer__copyright">
                        <div class="footer__copyright__text"><p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
  Copyright ©<script>document.write(new Date().getFullYear());</script> Đồ án <i class="fa fa-heart" aria-hidden="true"></i> by <a href="#" target="_blank">____</a>
  <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p></div>
                        <div class="footer__copyright__payment"><img src="resource/img/payment-item.png" alt=""></div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Js Plugins -->
    <script src="resource/js/jquery-3.3.1.min.js"></script>
    <script src="resource/js/bootstrap.min.js"></script>
    <script src="resource/js/jquery.nice-select.min.js"></script>
    <script src="resource/js/jquery-ui.min.js"></script>
    <script src="resource/js/jquery.slicknav.js"></script>
    <script src="resource/js/mixitup.min.js"></script>
    <script src="resource/js/owl.carousel.min.js"></script>
    <script src="resource/js/main.js"></script>   
</body>
</html>