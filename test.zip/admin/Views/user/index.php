<div class="panel-header panel-header-sm">
      </div>
<div class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Danh sách tài khoản</h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead class=" text-primary">
                                <tr>
                                    <th>
                                        STT
                                    </th>
                                    <th>
                                        Tên
                                    </th>
                                    <th>
                                        Tên tài khoản
                                    </th>
                                    <th>
                                        Chức vụ
                                    </th>
                                    <th>
                                       Chức năng
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($allUser as $key=>$value) {?>
                                <tr>
                                    <td>
                                        <?php echo $key+1; ?>
                                    </td>
                                    <td>
                                        <?php echo $value['Name']; ?>
                                    </td>
                                    <td>
                                        <?php echo $value['UserName']; ?>
                                    </td>
                                    <td>
                                        <?php echo $value['RoleName']; ?>
                                    </td>
                                    <td>
                                        Thêm,Xóa,Sửa
                                    </td>
                                </tr>
                                <?php } ?>                                                                                                         
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>