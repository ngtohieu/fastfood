<div class="panel-header panel-header-sm">
</div>
<div class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Danh sách sản phẩm</h4>
                    <a href="./sanpham/them">
                        <i class="now-ui-icons ui-1_simple-add"></i> Thêm sản phẩm
                    </a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead class=" text-primary">
                                <tr>
                                    <th>
                                        STT
                                    </th>
                                    <th>
                                        Tên
                                    </th>
                                    <th>
                                        Giá
                                    </th>
                                    <th>
                                        Danh mục
                                    </th>
                                    <th>
                                       Hình ảnh
                                    </th>
                                    <th>
                                       Chức năng
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($allProducts as $key=>$value) {?>
                                <tr>
                                    <td>
                                        <?php echo $key+1; ?>
                                    </td>
                                    <td>
                                        <?php echo $value['Name']; ?>
                                    </td>
                                    <td>
                                        <?php echo $value['Price']; ?>
                                    </td>
                                    <td>
                                        <?php echo $value['Category']; ?>
                                    </td>
                                    <td>
                                        <img width="50px;" src='<?php echo $value['Image']; ?>'/>
                                    </td>
                                    <td>
                                        Thêm,Xóa,Sửa
                                    </td>
                                </tr>
                                <?php } ?>                                                                                                         
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>