<?php

namespace Controllers;

class HomeController extends BaseController
{
    function __construct()
    {
        parent::__construct();
    }
    function __destruct()
    {   
    }
    function payload()
    {
        //echo "cho1";
    }

    public function index()
    {
        require PATH_ROOT ."/Models/mHome.php";
        $billCurrnetData = $home->getBillCurrentDate();
        include("./Views/home/index.php");
        include("./Views/template/footer.php");
    }
}
