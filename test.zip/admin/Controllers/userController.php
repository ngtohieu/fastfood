<?php

namespace Controllers;

class UserController extends BaseController
{
    function __construct()
    {
        parent::__construct();
    }
    function __destruct()
    {   
    }
    function payload()
    {
        //echo "cho1";
    }

    public function index()
    {
        require PATH_ROOT ."/Models/mUser.php";
        $allUser = $user->getUserAll();
        include("./Views/user/index.php");
        include("./Views/template/footer.php");
    }
}
