<?php
define("host","localhost");
define("dbName","fastfood");
define("user","root");
define("password","");
define("baseUrl","http://localhost:8080/test/admin/");