<?php
class Product extends DB_business {
    function __construct() 
    {
        // Khai báo tên bảng
        $this->_table_name = 'products';
         
        // Khai báo tên field id
        $this->_key = 'ID';
         
        // Gọi hàm khởi tạo cha
        parent::__construct();
    }

    public function getAll(){
        return $this->get_list("SELECT `products`.*, `category`.`Name` AS 'Category' FROM `products`,`category` WHERE `products`.`IDCategory` = `category`.`ID`");
    }

    public function getAllCategory(){
        return $this->get_list("SELECT `category`.`ID`,`category`.`Name` FROM `category`");
    }

    public function insertProduct($name,$price,$image,$category){
        return $this->add_new(array(
                'Name' => $name,
                'Price' => $price,
                'Image' => $image,
                'IDCategory' => $category,
            ));
    }
}
$product = new Product();