<?php
class User extends DB_business {
    function __construct() 
    {
        // Khai báo tên bảng
        $this->_table_name = 'users';
         
        // Khai báo tên field id
        $this->_key = 'ID';
         
        // Gọi hàm khởi tạo cha
        parent::__construct();
    }

    public function getUserAll(){
        return $this->get_list("SELECT `users`.*,`roles`.RoleName FROM `users`,`Roles` WHERE `users`.`role` = `Roles`.`ID`");
    }
}
$user = new User();