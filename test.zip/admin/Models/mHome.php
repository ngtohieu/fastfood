<?php
class Home extends DB_business {
    function __construct() 
    {
        // Khai báo tên bảng
        $this->_table_name = 'none';
         
        // Khai báo tên field id
        $this->_key = 'ID';
         
        // Gọi hàm khởi tạo cha
        parent::__construct();
    }

    public function getBillCurrentDate(){       
        return $this->get_list("SELECT COUNT(*) as 'Number',HOUR(`DateCreate`) as 'Hour' FROM `bills` WHERE DATE(`DateCreate`)=CURRENT_DATE() GROUP BY HOUR(`DateCreate`)")??[];
    }
}
$home = new Home();