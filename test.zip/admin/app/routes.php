<?php 

$router->get('/', 'HomeController@index');
$router->get('/login', 'LoginController@index');
$router->post('/login', 'LoginController@login');
$router->get('/logout', 'LoginController@logout');
$router->get('/user', 'UserController@index');
$router->get('/sanpham', 'ProductController@index');
$router->get('/sanpham/them', 'ProductController@add');
$router->post('/sanpham/them', 'ProductController@addProduct');