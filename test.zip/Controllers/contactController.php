<?php
namespace Controllers;

class ContactController{
    public function index(){
        include("./Views/contact/index.php");
    }

}